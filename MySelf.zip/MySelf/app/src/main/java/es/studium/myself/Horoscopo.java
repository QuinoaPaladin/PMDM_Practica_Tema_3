package es.studium.myself;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Horoscopo extends AppCompatActivity {


    int dia;
    int mes;
    int anio;

    ImageView i;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_horoscopo);

        i = (ImageView) findViewById( R.id.imgHoroscopo);

        Bundle extras = getIntent().getExtras();
        dia = extras.getInt("dia");
        mes = extras.getInt("mes");
        anio = extras.getInt("anio");

        if(mes==1)
        {
            if(dia<=20)
            {
                i.setImageResource(R.drawable.capricornio);
            }
            if(dia>=21)
            {
                i.setImageResource(R.drawable.acuario);
            }
        }

        else if(mes==2)
        {
            if(dia<=19)
            {
                i.setImageResource(R.drawable.acuario);
            }
            if(dia>=20)
            {
                i.setImageResource(R.drawable.piscis);
            }
        }

        else if(mes==3)
        {
            if(dia<=20)
            {
                i.setImageResource(R.drawable.piscis);
            }
            if(dia>=21)
            {
                i.setImageResource(R.drawable.aries);
            }
        }

        else if(mes==4)
        {
            if(dia<=20)
            {
                i.setImageResource(R.drawable.aries);
            }
            if(dia>=21)
            {
                i.setImageResource(R.drawable.tauro);
            }
        }
        else if(mes==5)
    {
        if(dia<=21)
        {
            i.setImageResource(R.drawable.tauro);
        }
        if(dia>=22)
        {
            i.setImageResource(R.drawable.geminis);
        }

    }
        else if(mes==6)
    {
        if(dia<=21)
        {
            i.setImageResource(R.drawable.geminis);
        }
        if(dia>=22)
        {
            i.setImageResource(R.drawable.cancer);
        }

    }
        else if(mes==7)
    {
        if(dia<=22)
        {
            i.setImageResource(R.drawable.cancer);
        }
        if(dia>=23)
        {
            i.setImageResource(R.drawable.leo);
        }

    }
        else if(mes==8)
    {
        if(dia<=22)
        {
            i.setImageResource(R.drawable.leo);
        }
        if(dia>=23)
        {
            i.setImageResource(R.drawable.virgo);
        }

    }
        else if(mes==9)
    {
        if(dia<=22)
        {
            i.setImageResource(R.drawable.virgo);
        }
        if(dia>=23)
        {
            i.setImageResource(R.drawable.libra);
        }

    }
        else if(mes==10)
    {
        if(dia<=22)
        {
            i.setImageResource(R.drawable.libra);
        }
        if(dia>=23)
        {
            i.setImageResource(R.drawable.escorpio);
        }

    }
        else if(mes==11)
    {
        if(dia<=22)
        {
            i.setImageResource(R.drawable.escorpio);
        }
        if(dia>=23)
        {
            i.setImageResource(R.drawable.sagitario);
        }

    }
        else if(mes==12)
    {
        if(dia<=21)
        {
            i.setImageResource(R.drawable.sagitario);
        }
        if(dia>=22)
        {
            i.setImageResource(R.drawable.capricornio);
        }
    }
    }


}