package es.studium.myself;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button btnAceptar;

    EditText etDia;
    EditText etMes;
    EditText etAnio;

    int intdia;
    int intmes;
    int intanio;

    String Sdia;
    String Smes;
    String Sanio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAceptar = findViewById(R.id.btnAceptar);
        btnAceptar.setOnClickListener(this);

        etDia = findViewById(R.id.txnDia);
        etMes = findViewById(R.id.txnMes);
        etAnio = findViewById(R.id.txnAnio);
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId()==(R.id.btnAceptar))
        {
            Sdia = etDia.getText().toString();
            intdia = Integer.parseInt(Sdia);

            Smes = etMes.getText().toString();
            intmes = Integer.parseInt(Smes);

            Sanio = etAnio.getText().toString();
            intanio = Integer.parseInt(Sanio);

            Toast.makeText(this, "Acuario", Toast.LENGTH_LONG);

            if(intdia>31)
            {
                Toast.makeText(this, "Error en día", Toast.LENGTH_SHORT);
            }
            else if(intmes>12)
            {
                Toast.makeText(this, "Error en mes", Toast.LENGTH_SHORT);
            }
            else if (intanio>2021)
            {
                Toast.makeText(this, "Error en año", Toast.LENGTH_SHORT);
            }
            else if(intdia<31)
            {
                if(intmes<12)
                {
                    if (intanio < 2022)
                    {
                        if(intanio>1930)
                        {
                            Intent intent = new Intent (MainActivity.this, Horoscopo.class);
                            Bundle datosAEnviar = new Bundle();
                            datosAEnviar.putInt("dia", intdia );
                            datosAEnviar.putInt("mes", intmes);
                            datosAEnviar.putInt("anio", intanio);
                            intent.putExtra("bundle", datosAEnviar);
                            startActivity(intent);

                            setContentView(R.layout.activity_horoscopo);
                        }
                    }

                }
            }
        }
    }
}